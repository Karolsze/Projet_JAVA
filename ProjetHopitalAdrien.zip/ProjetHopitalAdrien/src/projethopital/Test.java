/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projethopital;

import java.sql.SQLException;
import vue.Fenetre;
import ProjetHopital.Connexion;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import vue.BDDinsertion;
import vue.BDDinteractionDOCTEUR;
import vue.BDDinteractionINFIRMIER;
import vue.BDDinteractionMALADES;
import vue.BDDmodification;
import vue.FenConnexion;

/**
 *
 * @author adrie
 */
public class Test {

    public static Connexion c1;

    //toutes les fenetres que l'ont peut ouvrir
    public static BDDinteractionDOCTEUR fenBDDdocteur;
    public static BDDinteractionINFIRMIER fenBDDinfirmier;
    public static BDDinteractionMALADES fenBDDmalades;
    public static BDDmodification fenBDDmodif;
    public static BDDinsertion fenBDDinser;
    public Fenetre fen;

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

//      Fenetre fen = new Fenetre("Fenetre de gestion de l'hopital");
        FenConnexion fenc = new FenConnexion();
        Test t1 = new Test("hopital", "root", "");
        ArrayList<String> prout = new ArrayList<>();
        //nom de la liste
        prout.add("service");

        
        //les anciennes valeurs
        prout.add("REA");
        prout.add("Reanimation et Traumatologie");
        prout.add("A");
        prout.add("19");
        //les nouvelles valeurs
        prout.add("JCG");
        prout.add("Machintruc");
        prout.add("B");
        prout.add("5");
        

   

        modification(prout);       
        //FENETRES
        //fenBDDdocteur = new BDDinteractionDOCTEUR(c1);
        //fenBDDinfirmier = new BDDinteractionINFIRMIER(c1);
        //fenBDDmalades = new BDDinteractionMALADES(c1); 
        //fenBDDmodif = new BDDmodification(c1);
        //System.out.println(ExecuteDocteur("Safin","Marat", "Traumatologue", "19"));
    }

    public Test(String database, String login, String password) throws SQLException, ClassNotFoundException {
        c1 = new Connexion(database, login, password);
    }

    public Test(String usernameECE, String passwordECE, String loginDatabase, String passwordDatabase) throws SQLException, ClassNotFoundException {
        c1 = new Connexion(usernameECE, passwordECE, loginDatabase, passwordDatabase);
    }

    public void AfficherInformations(String table) {
        //On declare les tables
        ArrayList<Object> list = new ArrayList<Object>();
        ArrayList<Object> list2 = new ArrayList<Object>();
        ArrayList<Object> list3 = new ArrayList<Object>();

        if (table == "docteur") {

            try {
                list = c1.remplirChampsRequete("SELECT employe.nom,employe.prenom,employe.adresse FROM docteur INNER JOIN employe ON docteur.numero = employe.numero");
            } catch (SQLException ex) {
                Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                list2 = c1.remplirChampsRequete("SELECT docteur.numero FROM docteur");
            } catch (SQLException ex) {
                Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
            }

            System.out.println("Voici les informations de tout les docteur: ");

            for (int i = 0; i < list.size(); i++) {
                System.out.println("Docteur numero: " + list2.get(i));
                System.out.println(list.get(i));
            } ///Si tu clique on enleve la boucle for et on incremente le i
        }
        if (table == "infirmier") {
            try {
                list = c1.remplirChampsRequete("SELECT employe.nom,employe.prenom,employe.adresse FROM infirmier INNER JOIN employe ON infirmier.numero = employe.numero");
            } catch (SQLException ex) {
                Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                list2 = c1.remplirChampsRequete("SELECT infirmier.numero,infirmier.salaire,infirmier.rotation FROM infirmier");
            } catch (SQLException ex) {
                Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
            }

            System.out.println("Voici les informations de tout les docteur: ");

            for (int i = 0; i < list.size(); i++) {
                System.out.println("Infirmier numero: " + list2.get(i));
                System.out.println(list.get(i));
            } ///Si tu clique on enleve la boucle for et on incremente le i

        }

        if (table == "malade") {
            try {
                list = c1.remplirChampsRequete("SELECT malade.nom,malade.prenom,malade.adresse,malade.tel,malade.mutuelle FROM malade");
            } catch (SQLException ex) {
                Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
            }

            System.out.println("Voici les informations de tout les malades: ");

            for (int i = 0; i < list.size(); i++) {
                System.out.println(list.get(i));
            } ///Si tu clique on enleve la boucle for et on incremente le i
        }
    }

    public static ArrayList<ArrayList<ArrayList<String>>> ExecuteDocteur(String nom, String prenom, String specialite, String numero) throws SQLException, ArrayIndexOutOfBoundsException {
        //On declare les tables
        ArrayList<String> list = new ArrayList();
        ArrayList<String> list2 = new ArrayList();
        ArrayList<String> list3 = new ArrayList();
        ArrayList<String> list4 = new ArrayList();
        ArrayList<String> list5 = new ArrayList();
        ArrayList<String> listCopie = new ArrayList();
        ArrayList<ArrayList<String>> InfoDocteur = new ArrayList();
        ArrayList<ArrayList<ArrayList<String>>> TouteLesInfos = new ArrayList();

        //Les differentes requêtes qui auront lieux
        String requete = "";
        String requete2 = "";
        String requete3 = "";
        String requete4 = "";
        String requete5 = "";
        String requete6 = "";

        String requeteSpecia = "";
        String requeteSoigne = "";
        String requeteMalade = "";

        //On créer des boolean pour savoir si le champ est vide
        boolean nomB = true;
        boolean prenomB = true;
        boolean specialiteB = true;
        boolean numeroB = true;

        ///Si les champs sont vides les booleens sont faux
        if (nom.equals("")) {
            nomB = false;
        }
        if (prenom.equals("")) {
            prenomB = false;
        }
        if (specialite.equals("")) {
            specialiteB = false;
        }
        if (numero.equals("")) {
            numeroB = false;
        }

        //Si on recoit que des champs vides
        if ((!specialiteB) && (!numeroB) && (!nomB) && (!prenomB)) {
            System.out.println("Veuillez rentrer au moins une information");
        }

        //Si on recoit uniquement le nom du docteur ou bien uniquement le prenom ou les deux
        if (((nomB) && (!prenomB)) || ((!nomB) && (prenomB)) || ((nomB) && (prenomB))) {
            //on verifi son nom
            if ((nomB) && (!prenomB)) {
                requete = "SELECT employe.numero FROM employe WHERE nom = '" + nom + "'";
                requete2 = "SELECT employe.nom FROM employe WHERE nom = '" + nom + "'";
                requete3 = "SELECT employe.prenom FROM employe WHERE nom = '" + nom + "'";
                requete4 = "SELECT employe.adresse FROM employe WHERE nom = '" + nom + "'";
                requete5 = "SELECT employe.tel FROM employe WHERE nom = '" + nom + "'";
                requete6 = "SELECT * FROM employe WHERE nom = '" + nom + "'";
            }

            //on verifi son prenom
            if ((!nomB) && (prenomB)) {
                requete = "SELECT employe.numero FROM employe WHERE prenom = '" + prenom + "'";
                requete2 = "SELECT employe.nom FROM employe WHERE prenom = '" + prenom + "'";
                requete3 = "SELECT employe.prenom FROM employe WHERE prenom = '" + prenom + "'";
                requete4 = "SELECT employe.adresse FROM employe WHERE prenom = '" + prenom + "'";
                requete5 = "SELECT employe.tel FROM employe WHERE prenom = '" + prenom + "'";
                requete6 = "SELECT * FROM employe WHERE prenom = '" + prenom + "'";

            }

            //on verifi les prenom et le nom
            if ((nomB) && (prenomB)) {
                requete = "SELECT employe.numero FROM employe WHERE prenom = '" + prenom + "' AND nom = '" + nom + "'";
                requete2 = "SELECT employe.nom FROM employe WHERE prenom = '" + prenom + "' AND nom = '" + nom + "'";
                requete3 = "SELECT employe.prenom FROM employe WHERE prenom = '" + prenom + "' AND nom = '" + nom + "'";
                requete4 = "SELECT employe.adresse FROM employe WHERE prenom = '" + prenom + "' AND nom = '" + nom + "'";
                requete5 = "SELECT employe.tel FROM employe WHERE prenom = '" + prenom + "' AND nom = '" + nom + "'";
                requete6 = "SELECT * FROM employe WHERE prenom = '" + prenom + "' AND nom = '" + nom + "'";
            }

            //On verifi sa specialite
            requeteSpecia = "SELECT docteur.specialite FROM docteur INNER JOIN employe ON docteur.numero=employe.numero";

            list2 = c1.remplirChampsRequete(requeteSpecia);
            list.add(list2.get(0));
            list2 = c1.remplirChampsRequete(requete2);
            list.add(list2.get(0));
            list2 = c1.remplirChampsRequete(requete3);
            list.add(list2.get(0));
            list2 = c1.remplirChampsRequete(requete4);
            list.add(list2.get(0));
            list2 = c1.remplirChampsRequete(requete5);
            list.add(list2.get(0));

            list2 = c1.remplirChampsRequete(requete);

            //on regarde tout les numeros des malades qu'il soigne
            requeteSoigne = "SELECT soigne.no_malade FROM soigne WHERE soigne.no_docteur= " + list2.get(0);
            list3 = c1.remplirChampsRequete(requeteSoigne);

            for (int i = 0; i < list3.size(); i++) {
                //on regarde le prenom de tout les patient qu'il soigne
                requeteSoigne = "SELECT malade.nom,malade.prenom FROM malade INNER JOIN soigne ON malade.numero=" + list3.get(i);
                list4 = c1.remplirChampsRequete(requeteSoigne);
                listCopie.add(list4.get(i));
            }
            InfoDocteur.add(list);
            InfoDocteur.add(listCopie);
            TouteLesInfos.add(InfoDocteur);
        }

        //Si on recoit uniquement une specialite
        if ((!nomB) && (!prenomB) && (specialiteB) && (!numeroB)) {
            //On ajoute la specialite
            //Recherche des docteurs ayant cette specialité
            requete = "SELECT docteur.numero FROM docteur WHERE docteur.specialite = '" + specialite + "'";
            list = c1.remplirChampsRequete(requete);

            //On parcours le nombre de docteur 
            for (int i = 0; i < list.size(); i++) {
                //On affiche les infos du docteur 
                //requete="SELECT * FROM employe INNER JOIN docteur ON employe.numero="+list.get(i);
                requete = "SELECT employe.numero FROM employe INNER JOIN docteur ON employe.numero=" + list.get(i);
                requete2 = "SELECT employe.nom FROM employe INNER JOIN docteur ON employe.numero=" + list.get(i);
                requete3 = "SELECT employe.prenom FROM employe INNER JOIN docteur ON employe.numero=" + list.get(i);
                requete4 = "SELECT employe.adresse FROM employe INNER JOIN docteur ON employe.numero=" + list.get(i);
                requete5 = "SELECT employe.tel FROM employe INNER JOIN docteur ON employe.numero=" + list.get(i);

                //on ajoute les infos du docteur
                list5 = new ArrayList();

                list2 = c1.remplirChampsRequete(requete);
                list5.add(list2.get(0));
                list2 = c1.remplirChampsRequete(requete2);
                list5.add(list2.get(0));
                list2 = c1.remplirChampsRequete(requete3);
                list5.add(list2.get(0));
                list2 = c1.remplirChampsRequete(requete4);
                list5.add(list2.get(0));
                list2 = c1.remplirChampsRequete(requete5);
                list5.add(list2.get(0));

                //on regarde tout les numeros des malades qu'il soigne
                requeteSoigne = "SELECT soigne.no_malade FROM soigne WHERE soigne.no_docteur=" + list.get(i);
                list3 = c1.remplirChampsRequete(requeteSoigne);

                listCopie = new ArrayList();
                //On parcoure tout les malades
                for (int j = 0; j < list3.size(); j++) {
                    requeteSoigne = "SELECT malade.nom,malade.prenom FROM malade INNER JOIN soigne ON malade.numero=" + list3.get(j);
                    list4 = c1.remplirChampsRequete(requeteSoigne);
                    listCopie.add(list4.get(i));
                }
                //On ajoute les informations
                InfoDocteur.add(list5);
                InfoDocteur.add(listCopie);
                TouteLesInfos.add(InfoDocteur);
                InfoDocteur = new ArrayList();

            }

        }

        //Si on recoit uniquement un numero peut importe la specialite
        if ((!nomB) && (!prenomB) && (numeroB)) {
            //On obtient toutes les informations de l'employé de manière séparée
            requete = "SELECT employe.numero FROM employe WHERE numero = '" + numero + "'";
            requete2 = "SELECT employe.nom FROM employe WHERE numero = '" + numero + "'";
            requete3 = "SELECT employe.prenom FROM employe WHERE numero = '" + numero + "'";
            requete4 = "SELECT employe.adresse FROM employe WHERE numero = '" + numero + "'";
            requete5 = "SELECT employe.tel FROM employe WHERE numero = '" + numero + "'";
            requete6 = "SELECT * FROM employe WHERE WHERE numero = '" + numero + "'";

            //On verifi sa specialite
            requeteSpecia = "SELECT docteur.specialite FROM docteur INNER JOIN employe ON " + numero + "=employe.numero";

            //On ajoute toutes les informations dans un tableau
            list2 = c1.remplirChampsRequete(requeteSpecia);

            list.add(list2.get(0));
            list2 = c1.remplirChampsRequete(requete2);
            list.add(list2.get(0));
            list2 = c1.remplirChampsRequete(requete3);
            list.add(list2.get(0));
            list2 = c1.remplirChampsRequete(requete4);
            list.add(list2.get(0));
            list2 = c1.remplirChampsRequete(requete5);
            list.add(list2.get(0));

            list2 = c1.remplirChampsRequete(requete);

            //on regarde tout les numeros des malades qu'il soigne
            requeteSoigne = "SELECT soigne.no_malade FROM soigne WHERE soigne.no_docteur= " + numero;
            list3 = c1.remplirChampsRequete(requeteSoigne);

            for (int i = 0; i < list3.size(); i++) {
                //on regarde le prenom de tout les patient qu'il soigne
                requeteSoigne = "SELECT malade.nom,malade.prenom FROM malade INNER JOIN soigne ON malade.numero=" + list3.get(i);
                list4 = c1.remplirChampsRequete(requeteSoigne);
                listCopie.add(list4.get(i));
            }
            InfoDocteur.add(list);
            InfoDocteur.add(listCopie);
            TouteLesInfos.add(InfoDocteur);

        }
        //Info docteur contient 2 cases: le nom des malades qu'il soigne ainsi que ses informations personnelles
        return TouteLesInfos;
    }

    public static void modification(ArrayList<String> arr) {

        String req = "";

        if ("docteur".equals(arr.get(0))) {
            req = "UPDATE docteur SET numero=" + arr.get(1) + ", specialite=\"" + arr.get(2) + "\" WHERE numero=" + arr.get(3) + " AND specialite=\"" + arr.get(4) + "\"";
        }

        if ("malade".equals(arr.get(0))) {
            req = "UPDATE malade SET numero=" + arr.get(1) + ", nom=\"" + arr.get(2) + "\", prenom=\"" + arr.get(3) + "\", adresse=\"" + arr.get(4) + "\", tel=\"" + arr.get(5) + "\", mutuelle=\"" + arr.get(6)
                    + "\" WHERE numero=" + arr.get(7) + " AND nom=\"" + arr.get(8) + "\" AND prenom=\"" + arr.get(9) + "\" AND adresse=\"" + arr.get(10) + "\" AND tel=\"" + arr.get(11) + "\" AND mutuelle=\"" + arr.get(12) + "\"";
        }

        if ("chambre".equals(arr.get(0))) {
            req = "UPDATE chambre SET code_service=\"" + arr.get(1) + "\",no_chambre=" + arr.get(2) + ", surveillant=" + arr.get(3) + ", nb_lits=" + arr.get(4)
                    + " WHERE code_service=\"" + arr.get(5) + "\" AND no_chambre=" + arr.get(6) + " AND surveillant=" + arr.get(7) + " AND nb_lits=" + arr.get(8) + "";
        }

        if ("employe".equals(arr.get(0))) {
            req = "UPDATE employe SET numero=" + arr.get(1) + ",nom=\"" + arr.get(2) + "\",prenom=\"" + arr.get(3) + "\",adresse=\"" + arr.get(4) + "\",tel=\"" + arr.get(5)
                    + "\" WHERE numero=" + arr.get(6) + " AND nom=\"" + arr.get(7) + "\" AND prenom=\"" + arr.get(8) + "\"AND adresse=\"" + arr.get(9) + "\" AND tel=\"" + arr.get(10) + "\"";
        }

        if ("hospitalisation".equals(arr.get(0))) {
            req = "UPDATE hospitalisation SET no_malade=" + arr.get(1) + ",code_service=\"" + arr.get(2) + "\",no_chambre=" + arr.get(3) + ",lit=" + arr.get(4)
                    + " WHERE no_malade=" + arr.get(5) + " AND code_service=\"" + arr.get(6) + "\" AND no_chambre=" + arr.get(7) + " AND lit=" + arr.get(8) + "";
        }

        if ("infirmier".equals(arr.get(0))) {
            req = "UPDATE infirmier SET numero=" + arr.get(1) + ",code_service=\"" + arr.get(2) + "\",rotation=\"" + arr.get(3) + "\",salaire=" + arr.get(4)
                    + " WHERE numero=" + arr.get(5) + " AND code_service=\"" + arr.get(6) + "\" AND rotation=\"" + arr.get(7) + "\" AND salaire=" + arr.get(8) + "";

        }

        if ("service".equals(arr.get(0))) {
            req = "UPDATE service SET code=\"" + arr.get(1) + "\",nom=\"" + arr.get(2) + "\",batiment=\"" + arr.get(3) + "\",directeur=" + arr.get(4)
                    + " WHERE code=\"" + arr.get(5) + "\" AND nom=\"" + arr.get(6) + "\" AND batiment=\"" + arr.get(7) + "\" AND directeur=" + arr.get(8) + "";
        }

        if ("soigne".equals(arr.get(0))) {
            req = "UPDATE soigne SET no_docteur=" + arr.get(1) + ",no_malade=" + arr.get(2) + " WHERE  no_docteur=" + arr.get(3) + " AND no_malade=" + arr.get(4) + "";
        }
        try {
            c1.executeUpdate(req);
        } catch (SQLException ex) {
            Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public ArrayList remplirChampsRequete(String str) throws SQLException {

        return c1.remplirChampsRequete(str);

    }

    public void ouvreFenetre(String str) {

        if (str.equals("docteur")) {
            System.out.println("Ouverture de la fenetre");
            try {
                fenBDDdocteur = new BDDinteractionDOCTEUR(c1);
            } catch (SQLException ex) {
                Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

        if (str.equals("malades")) {
            try {
                fenBDDmalades = new BDDinteractionMALADES(c1);
            } catch (SQLException ex) {
                Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

        if (str.equals("infirmier")) {
            try {
                fenBDDinfirmier = new BDDinteractionINFIRMIER(c1);
            } catch (SQLException ex) {
                Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

        if (str.equals("modification")) {
            fenBDDmodif = new BDDmodification(c1);

        }

        if (str.equals("insertion")) {
            fenBDDinser = new BDDinsertion(c1);
        }

        if (str.equals("Menu")) {
            fen = new Fenetre(this);

        }
    }

}
