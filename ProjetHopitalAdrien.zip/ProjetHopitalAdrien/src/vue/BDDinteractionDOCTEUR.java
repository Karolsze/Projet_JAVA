/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vue;

import ProjetHopital.Connexion;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author 931702281
 */
public class BDDinteractionDOCTEUR extends BDDinteractionBASE{

    public BDDinteractionDOCTEUR(Connexion c1) throws SQLException {
        
        super(c1, "DOCTEUR", "Nom", "Prénom", "Spécialité", "Numéros", 
                "SELECT nom FROM docteur,employe WHERE docteur.numero=employe.numero ORDER BY nom",
                "SELECT prenom FROM docteur,employe WHERE docteur.numero=employe.numero ORDER BY prenom",
                "SELECT DISTINCT specialite FROM docteur,employe WHERE docteur.numero=employe.numero ORDER BY specialite",
                "SELECT docteur.numero FROM docteur,employe WHERE docteur.numero=employe.numero ORDER BY docteur.numero");
    }

    
    @Override
    public void affiche_resultat(ArrayList<ArrayList<String>> arr) {
        
        String resultat="sdferzfzf";
        ArrayList arr1=arr.get(0);
        ArrayList<String> arr2=arr.get(1);
        
        resulatstotal.setText(resultat);
        this.revalidate();
        this.repaint();
        
        for(int i=0;i<arr2.size();i++)
        {
            list5.addItem(arr2.get(i));
        }
        
        this.revalidate();
        this.repaint();
    }
    
}
